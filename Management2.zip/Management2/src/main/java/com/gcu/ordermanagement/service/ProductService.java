package com.gcu.ordermanagement.service;

import org.springframework.stereotype.Service;

import com.gcu.ordermanagement.model.Product;

@Service
public class ProductService {
	public void createProduct(Product product) {
		// Business logic for creating a product
	}
}
